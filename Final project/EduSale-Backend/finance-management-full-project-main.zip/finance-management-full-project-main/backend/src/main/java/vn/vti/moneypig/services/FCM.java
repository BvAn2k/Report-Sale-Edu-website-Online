//package vn.vti.moneypig.services;
//
//public class FCM {
//
//    public void pushNotification()
//    {
//
//    }
//
//    public void pushOne(){
//
//    }
//
//    public void pushMany()
//    {
//
//    }
//
//    public void pushToUser()
//    {
//
//    }
//    public void pushToTopic()
//    {
//
//    }
//
//    public void pushToCustomerId()
//    {
//
//    }
//
//    public void pushToCustomers(){
//
//    }
//
//    public void pushToPartners()
//    {
//
//    }
//
//    public void pushToPartnerId()
//    {
//
//    }
//
//}
