package vn.vti.moneypig.models;

public class PriceService {

    private Long id;
    private String serviceType;

    private float hours;
    private float price;

}
