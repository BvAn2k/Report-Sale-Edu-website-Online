package vn.vti.moneypig.models;

public class Gift {
}
