package vn.vti.moneypig.models;

public class Address {
    private String city;
    private String district;

}
