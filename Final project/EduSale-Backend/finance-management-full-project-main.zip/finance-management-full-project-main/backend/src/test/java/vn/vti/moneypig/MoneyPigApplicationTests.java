package vn.vti.moneypig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MoneyPigApplicationTests {

	@Test
	void contextLoads() {
	}

}
