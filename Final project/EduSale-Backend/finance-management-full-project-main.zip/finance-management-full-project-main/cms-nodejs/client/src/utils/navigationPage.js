// import { useNavigate } from "react-router-dom";

// export const GotoCreateNew =()=>{
//     const navigate = useNavigate();

//     navigate("/admin/users/create-new");
// }
// export const GotoAdmin =()=>{
//     const navigate = useNavigate();

//     navigate("/admin");
// }
// export const GotoUser =()=>{
//     ///admin/users
//     const navigate = useNavigate();

//     navigate("/admin/users");
// }